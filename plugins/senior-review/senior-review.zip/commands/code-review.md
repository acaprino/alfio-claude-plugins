---
description: >
  Unified code review - auto-detects scope and runs architecture, security, dead-code and VCS-hygiene analysis in parallel, then optionally fixes and cleans up what it found. Automatically uses X-ray context if available.
  TRIGGER WHEN: the user asks for a code review, PR review, branch audit, security/architecture analysis of recent changes, or asks to find and remove dead code, unused exports, unused dependencies, orphan assets, or generated artifacts committed to git.
  DO NOT TRIGGER WHEN: a full multi-phase pipeline is needed (use /senior-review:team-review) or reviewing a single file for style (use clean-code).
argument-hint: "[PR number | --branch <name> | --commits N] [--fix] [--auto-comment] [--strict] [--security-focus] [--fast] [--rigorous]"
---

# Code Review

You are a thorough code reviewer. Your job is to review code changes (uncommitted edits, recent commits, a pull request, or a branch diff), analyze them in depth, and produce a structured review with confidence-scored findings. Optionally post review comments directly on PRs.

## CRITICAL RULES

1. **Always review in context.** Read full files, not just diffs. Understand what the code does before judging changes.
2. **Score every finding.** Each finding gets a confidence score (0-100) indicating how certain you are it's a real issue.
3. **Check CLAUDE.md compliance.** If the project has a CLAUDE.md, verify changes follow its conventions.
4. **Never enter plan mode.** Execute immediately.
5. **Run agents in parallel.** Fire all review agents in a single response.
6. **Skip documentation files.** Ignore `.md`, `.txt`, `.rst`, `README*`, `CHANGELOG*`, `LICENSE*`. Focus only on code.

## Step 0: Pre-Review Skip Check (PR only)

If `$ARGUMENTS` contains a PR number (Case C), run a quick eligibility check **before** gathering any context. Launch a **haiku** agent that checks:

```bash
# Fetch PR metadata
gh pr view <N> --json state,isDraft,author,title,labels

# Check for prior Claude comments
gh pr view <N> --comments --json comments --jq '.comments[].author.login'
```

**Skip the review and stop** if ANY of these are true:
- PR state is `CLOSED` or `MERGED`
- PR is a draft (`isDraft: true`)
- PR is trivial/automated: author is a bot, title matches version-only bumps (`chore(deps):`, `bump *`, `Merge branch`), or has label `skip-review`
- Claude has already commented on this PR (check for `claude` or `github-actions[bot]` with Claude-style review content in comments)

**Still review** Claude-generated PRs (author is Claude but content is real code).

If skipped, print the reason and stop:
```
Skipping review: [PR is closed / PR is draft / PR is trivial / Already reviewed]
```

If not a PR review (Cases A, B, D, E), skip this step entirely.

---

## Step 1: Identify Review Target

From `$ARGUMENTS`, determine what to review using this priority:

**Case A -- Uncommitted/staged changes exist** (no explicit PR or branch arg):

```bash
git diff --name-only          # unstaged changes
git diff --cached --name-only # staged changes
```

If either has results, use uncommitted changes as the review target. The diff source is "uncommitted changes".

**Case B -- `--commits N` flag provided:**

Use `git diff HEAD~N..HEAD` as the review target. The diff source is "last N commits".

**Case C -- PR number provided** (e.g. `42`, `#42`):

```bash
gh pr view 42 --json number,title,body,baseRefName,headRefName,files
gh pr diff 42
```

**Case D -- `--branch <name>` provided:**

```bash
git log main..<branch> --oneline
git diff main...<branch>
```

**Case E -- No arguments, no uncommitted changes:**

Detect current branch and compare against main/master:

```bash
CURRENT=$(git branch --show-current)
BASE=$(git symbolic-ref refs/remotes/origin/HEAD 2>/dev/null | sed 's@^refs/remotes/origin/@@' || echo "main")
git diff ${BASE}...${CURRENT}
```

If the branch is main/master with no diff, fall back to last commit (`HEAD~1..HEAD`).

### Filter code files

Exclude: `.md`, `.txt`, `.rst`, `.json` (config-only), `.yaml`/`.yml` (config-only), images, lock files.
Include: source code files (`.py`, `.js`, `.ts`, `.tsx`, `.jsx`, `.rs`, `.go`, `.java`, `.rb`, `.css`, `.scss`, `.html`, etc.)

If no code files remain, say so and stop.

### Fullstack App Auto-Detection

Detect if the codebase is a fullstack application by checking for **2+ of these signals**:

- `package.json` with frontend framework (react, vue, svelte, angular, next, nuxt)
- Backend framework config (`pyproject.toml` with fastapi/django/flask, `package.json` with express/nest/hono, `Cargo.toml` with actix/axum)
- API route definitions (files matching `*/routes/*`, `*/api/*`, `*/endpoints/*`)
- Tauri config (`tauri.conf.json`, `Cargo.toml` with tauri)
- Electron config (`electron-builder.yml`, main process with `BrowserWindow`)
- Mobile config (`android/`, `ios/`, `capacitor.config.ts`, react-native)
- `docker-compose.yml` with multiple services

If 2+ signals found, set `FULLSTACK_APP=true` and run Agent D (Platform Engineering Review) in Step 3.

## Step 1b: Intent Discovery

Before diving into file contents, understand **what the change is trying to accomplish**. Run a single bash call:

```bash
echo "BRANCH:" && git rev-parse --abbrev-ref HEAD && echo "COMMITS:" && git log --oneline ${MERGE_BASE:-HEAD~1}..HEAD
```

Combined with conversation context (user description, PR title/body if available), write a 2-3 line intent summary:

```
Intent: Simplify tax calculation by replacing the multi-tier rate lookup
with a flat-rate computation. Must not regress edge cases in tax-exempt handling.
```

**Pass this intent to every agent** in Step 3. Intent shapes how hard each reviewer looks -- a "fix typo" intent means less scrutiny than a "rewrite auth middleware" intent.

**When intent is ambiguous:** Ask one question: "What is the primary goal of these changes?" Do not proceed until intent is established.

## Step 2: Gather Context

For each changed code file:

1. **Read the full file** -- understand surrounding context
2. **Get the diff** -- know exactly what changed
3. **Get recent commit history for changed files** -- understand the business context behind the code

```bash
git log -n 5 --oneline <file>
```

4. **Check for past PR comments** on the same files (if reviewing a PR):

```bash
gh api repos/{owner}/{repo}/pulls/{number}/comments --jq '.[].path' | sort -u
```

5. **Read CLAUDE.md** if it exists -- note project conventions, naming rules, patterns

6. **Check for deep-dive context** (optional -- requires `codebase-xray` plugin) -- if `.deep-dive/` exists and contains completed analysis files:
   - Read `.deep-dive/01-structure.md` for structural context
   - Read `.deep-dive/03-flows.md` for execution flow context
   - Read `.deep-dive/04-semantics.md` for design decision context
   - Read `.deep-dive/05-risks.md` for known risk context
   - Include a "Deep Dive Context" section in each agent's prompt (see template below)
   - Note in the review output that deep-dive context was used
   - If `.deep-dive/` does not exist or is incomplete, proceed normally without it -- this is expected behavior when the `codebase-xray` plugin is not installed or hasn't been run

### Deep Dive Context Template

When deep-dive output is available, append this section to each agent prompt after existing context sections:

```
## Deep Dive Context

The following context was gathered from a prior deep-dive analysis. Use it to
strengthen your review. Do NOT re-report findings already covered here --
instead focus on new issues or issues that become apparent when combining
this context with your specialized perspective.

### Structure & Flows
[Insert relevant excerpts from 01-structure.md and 03-flows.md]

### Design Decisions & Assumptions
[Insert relevant excerpts from 04-semantics.md]

### Known Risks
[Insert relevant excerpts from 05-risks.md]
```

## Step 2b: Large Change Set Handling

Before proceeding, check the total size of changed code:

```bash
git diff --shortstat  # or the equivalent for the detected diff source
```

If total changed lines exceed 500, batch the files into groups of 3-5 files per agent invocation. Run each batch sequentially, consolidating findings across batches before scoring. This prevents context window overflow and "lost in the middle" attention degradation.

## Step 3: Run Parallel Review Agents

**Agent tool parameters (use ONLY these):** `description` (required), `prompt` (required), `subagent_type`, `run_in_background`, `model`, `isolation`, `resume`. Do NOT pass any other parameters -- the Agent tool rejects unknown fields.

### Shared Instructions for All Agents

Include these instructions in every agent prompt:

```
## Intent
[paste the 2-3 line intent summary from Step 1b]

## Diff Scope & Pre-existing Classification

Classify every finding into one of three tiers:

- **Primary** -- lines added or modified in the diff. Your main focus. Full confidence.
- **Secondary** -- unchanged code in the same function/block as a changed line. Report
  if the diff makes the issue newly relevant, noting the interaction.
- **Pre-existing** -- issues in unchanged code unrelated to the diff. Mark these with
  `[PRE-EXISTING]` prefix. They are reported separately and do NOT count toward the verdict.

Rule: if you'd flag the same issue on an identical diff without the surrounding file,
it's pre-existing. If the diff makes it newly relevant, it's secondary.
```

Run all agents **in parallel** in a single response (Agent C only when UI files are in scope):

### Agent A: Code Audit (Architecture + Failure Flow + Pattern Consistency + Scoring)

```
Agent tool call:
  - description: "Code audit for senior-review command"
  - subagent_type: "senior-review:code-auditor"
  - run_in_background: true
  - prompt: |
    Perform a comprehensive code audit of the following changes covering architecture,
    failure flow analysis, pattern consistency, and quality scoring.
    You have both the diff AND the full file contents for context.

    ## Changed Files
    [list of changed code files with line counts]

    ## Full File Contents
    [paste full contents of each changed file]

    ## Diff
    [paste the git diff output]

    ## Recent Commit History
    [paste git log output -- shows business context for changed files]

    ## Project Conventions (from CLAUDE.md)
    [paste relevant conventions, or "none found"]

    ## Instructions
    Analyze the CHANGED code in context across all dimensions:

    **Architecture & Code Quality:**
    1. Design concerns -- coupling, broken abstractions, inappropriate patterns
    2. Code quality -- naming, complexity, duplication
    3. Error handling -- missing or incorrect in new/modified code
    4. Over/under-engineering -- is the solution appropriately scoped?
    5. CLAUDE.md compliance -- do changes follow project conventions?
    6. Flow correctness -- trace modified flows within provided files. If the flow calls external modules not present in context, state "Cannot verify downstream impact in [Module] -- out of scope" rather than guessing.

    **Failure Flow Analysis:**
    7. Resource lifecycle -- are DB connections, file handles, temp files cleaned up on BOTH success AND error paths (try/finally)? If the process is killed during an async operation, what state is left behind?
    8. Persisted state validity -- if code writes cache/state files for later resume, is there a validity key to detect stale data? Can a resumed run silently produce wrong results?
    9. Kill point analysis -- for each await/async operation, simulate termination. What persisted state is left inconsistent?
    10. Cache invalidation -- can stale cached results be silently mixed with fresh results?
    11. Concurrency under failure -- if one task fails or parent is killed, what happens to siblings?

    **Pattern Consistency:**
    12. Identify dominant patterns per file, flag deviations in the diff
    13. Run the 16-item anti-pattern checklist
    14. Check CLAUDE.md compliance

    **Scoring:**
    15. Produce a quantitative Code Quality Score (Security, Performance, Maintainability, Consistency, Resilience, Overall -- each X/10)

    For each finding: severity (Critical/High/Medium/Low), file + line, confidence (0-100), concrete fix.
    Include the full scoring table in your output.
```

### Agent B: Security Assessment

```
Agent tool call:
  - description: "Security review for senior-review command"
  - subagent_type: "senior-review:security-auditor"
  - run_in_background: true
  - prompt: |
    Review the following code changes for security vulnerabilities.
    You have both the diff AND the full file contents for context.

    ## Changed Files
    [list of changed code files]

    ## Full File Contents
    [paste full contents of each changed file]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Check the CHANGED code for:
    1. Injection risks -- SQL, command, XSS injection
    2. Input validation -- missing or insufficient
    3. Auth/authz -- flawed logic, missing checks, privilege escalation
    4. Secrets exposure -- hardcoded credentials, tokens, keys
    5. Insecure defaults -- debug mode, verbose errors, permissive CORS
    6. Dependency risks -- new packages trustworthy and up to date?
    7. Data exposure -- sensitive data in logs, errors, responses

    For each finding: severity, CWE if applicable, file + line, confidence (0-100), attack scenario, concrete fix.
```

### Agent B2: Dead Code, Unused Parameters & VCS Hygiene

This is the **lite** codebase-hygiene pass: dimensions D1 (dead code) and D3
(VCS hygiene) scoped to the diff. The **full** pass, covering orphan assets,
dependency and barrel-file hygiene, and stale documentation across the whole
codebase, belongs to `senior-review:cleanup-auditor` in
`/senior-review:team-review`. Do not widen this agent's scope to reach it.

```
Agent tool call:
  - description: "Dead code, lint and VCS hygiene detection for senior-review command"
  - subagent_type: "general-purpose"
  - run_in_background: true
  - prompt: |
    Detect dead code, unused parameters, and VCS hygiene defects in the files
    changed by the diff. Use BOTH automated tools AND manual analysis.

    ## Changed Files
    [list of changed code files with line counts]

    ## Full File Contents
    [paste full contents of each changed file]

    ## Diff
    [paste the git diff output]

    ## Phase 1: Automated Lint (MANDATORY)

    You MUST run actual linting tools via Bash on the changed files. Do NOT
    skip this phase or substitute it with manual reading.

    **Auto-detect language from changed file extensions:**

    ### Python files (.py)

    Run ruff on EACH changed Python file. Use the project's ruff config
    first (respects pyproject.toml/ruff.toml rules including isort, style
    checks, etc.). Only fall back to a manual --select if no config exists:

    ```bash
    # Step 1: Check if project has ruff config
    # Look for [tool.ruff] in pyproject.toml, or ruff.toml/.ruff.toml

    # Step 2a: If ruff config exists -- use it (catches ALL configured rules)
    ruff check --output-format json <file>

    # Step 2b: If NO ruff config -- use broad defaults
    ruff check --select E,F,I,W,ARG --output-format json <file>
    ```

    Rule coverage with broad defaults:
    - E: pycodestyle errors (E402 module-level import not at top, etc.)
    - F: pyflakes (F401 unused imports, F841 unused variables, F811 redefined names)
    - I: isort (I001 import sorting)
    - W: pycodestyle warnings
    - ARG: unused arguments (ARG001-ARG005)

    If ruff is not installed, attempt `pip install ruff` (or `uv pip install ruff`)
    then retry. If installation fails, note it and proceed to Phase 2.

    Also run vulture on each changed Python file if available:

    ```bash
    vulture --min-confidence 80 <file>
    ```

    If vulture is not installed, skip it (ruff covers the critical rules).

    ### TypeScript/JavaScript files (.ts, .tsx, .js, .jsx)

    If the project has a tsconfig.json, run:

    ```bash
    npx knip --include files,exports,dependencies --no-progress
    ```

    If knip is not available, use the TypeScript compiler for unused checks:

    ```bash
    npx tsc --noEmit --noUnusedLocals --noUnusedParameters 2>&1 | grep -E "(changed files pattern)"
    ```

    ### Other languages

    Skip automated lint; rely on Phase 3 manual analysis.

    ## Phase 2: VCS Hygiene (MANDATORY)

    Dead code is not the only hygiene defect a diff can introduce. Check the
    changed files for artifacts that should never have been committed. This
    phase is cheap and its false-positive rate is near zero, which is why it
    runs on every review instead of waiting for a full team-review.

    Scope it to the changed files only, same as Phase 1.

    ```bash
    # 1. Generated artifacts newly tracked by this diff
    #    (build output, bundles, coverage, compiled assets, lockfile-adjacent
    #     caches, editor and OS metadata)
    git diff --name-only --diff-filter=A $BASE...HEAD | grep -iE \
      '(^|/)(dist|build|out|coverage|\.next|\.nuxt|target|__pycache__|node_modules)/|\.(pyc|pyo|class|o|so|dll|map|tsbuildinfo)$|(^|/)\.DS_Store$|(^|/)Thumbs\.db$'

    # 2. Filesystem garbage (shell-redirection artifacts and stray files)
    git diff --name-only --diff-filter=A $BASE...HEAD | grep -iE \
      '(^|/)(nul|con|prn|aux)$|\.(bak|old|orig|swp|tmp)$'

    # 3. .gitignore gap: for every hit above, check whether a pattern already
    #    covers it. A tracked file matching an existing pattern means it was
    #    committed before the pattern was added and needs `git rm --cached`.
    git check-ignore -v <path>
    ```

    Report each hit as a finding. Never delete anything here: this command's
    Step 7c owns removal, and its `gitignore` phase owns the `git rm --cached`
    plus pattern append. Name the phase in your finding so Step 7c can act on
    it without re-deriving the classification.

    ## Phase 3: Manual Diff Analysis

    After collecting lint results, also manually analyze the diff for issues
    that linters miss:

    1. Unreachable code -- code after return/raise/break added by the diff
    2. Unused exports -- new exports that no consumer imports
    3. Orphaned code -- existing code that became dead because the diff
       removed its only caller
    4. Parameters accepted but never read in the function body (cross-check
       with ARG results from Phase 1 to avoid duplicates)

    ## Filtering Rules

    Report ONLY findings related to code introduced or exposed by the diff.

    Do NOT flag:
    - Pre-existing issues unrelated to the diff
    - Framework conventions (Django views, pytest fixtures, signal handlers,
      route decorators, FastAPI dependencies, click/typer callbacks)
    - Symbols exported via __all__, used via getattr, referenced dynamically,
      or used as configuration keys looked up at runtime
    - Dunder methods (__init__, __str__, etc.)
    - Parameters prefixed with _ (conventional unused marker)
    - Abstract method parameters (required by interface contract)
    - **kwargs / **args intentionally passed through

    To filter: cross-reference each lint finding's file and line against the
    diff hunks. Discard findings on lines NOT touched by the diff.

    ## Output Format

    For each finding provide:
    - Source: "ruff [RULE]", "vulture", "knip", "tsc", "vcs", or "manual"
    - Severity (High / Medium / Low)
    - File + line (for VCS findings, the path alone)
    - Confidence score (0-100)
    - What is unused or misplaced, and why
    - Recommended action (remove, prefix with _, verify dynamic usage, add to
      __all__, `git rm --cached` plus a .gitignore pattern)
    - Fix phase: the Step 7c cleanup phase that would resolve it
      (`exports` for dead code, `garbage` or `gitignore` for VCS findings)
```

### Agent C: UI Race Condition Analysis

**Only run this agent if the changed files include UI/frontend code** (`.tsx`, `.jsx`, `.vue`, `.svelte`, `.component.ts`, `.qml`, or files containing scroll/focus/layout manipulation).

```
Agent tool call:
  - description: "UI race condition analysis for senior-review command"
  - subagent_type: "senior-review:ui-race-auditor"
  - run_in_background: true
  - prompt: |
    Analyze the following UI code changes for race conditions between async rendering,
    layout, and event handlers.
    You have both the diff AND the full file contents for context.

    ## Changed Files
    [list of changed code files]

    ## Full File Contents
    [paste full contents of each changed file]

    ## Diff
    [paste the git diff output]

    ## Project Conventions (from CLAUDE.md)
    [paste relevant conventions, or "none found"]

    ## Instructions
    Analyze the CHANGED code for UI timing bugs:

    1. **Async-Render-Event Triangle** -- Map data sources that trigger re-renders,
       layout-dependent operations (scroll, focus, measurement), and event handlers
       that read layout state. Identify where these three interact.

    2. **Scroll Race Analysis** -- For every scrollIntoView, scrollTop assignment,
       or scrollToIndex call: is the layout complete when it fires? Can reflow after
       the call shift scrollTop and trigger false "user scrolled" detection?

    3. **Batch Render Timing** -- For bulk state updates (history restore, list load,
       large dataset): do effects/callbacks that depend on layout fire before or
       after all items are rendered and measured?

    4. **Stale Closure Audit** -- Do event handlers, timers, or observers capture
       DOM references or layout values that can go stale between capture and use?

    5. **Programmatic vs User Event Discrimination** -- Do scroll/focus/resize
       handlers distinguish between programmatic manipulation and genuine user
       interaction? Missing guards cause false state transitions.

    6. **Cross-Component Layout Coupling** -- Does component A resize/reflow and
       affect component B's scroll position, measurements, or visibility without
       B being notified?

    For each finding: severity (Critical/High/Medium/Low), step-by-step timeline
    (T0->T1->...->RESULT), file + line, confidence (0-100), concrete fix.
```

### Agent D: Platform Engineering Review

**Only run this agent if fullstack app signals were detected** (2+ signals from auto-detection in Step 1). Skip entirely for libraries, CLI tools, or single-layer projects.

**Skip if the `platform-engineering` plugin is not installed.** It is an `optionalDependency`, so the spawn fails with "Agent type not found" when it is absent. Report the dimension as skipped for that reason instead, so the gap is visible in the report rather than silent.

```
Agent tool call:
  - description: "Platform engineering review for senior-review command"
  - subagent_type: "platform-engineering:platform-reviewer"
  - run_in_background: true
  - prompt: |
    Review the following code changes against the platform-engineering rulebook.
    You have both the diff AND the full file contents for context.

    ## Platforms Detected
    [list detected platform signals: SPA, PWA, Mobile, Electron, Tauri]

    ## Changed Files
    [list of changed code files]

    ## Full File Contents
    [paste full contents of each changed file]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Evaluate the CHANGED code against platform-engineering rules:
    1. **Server validation**: Is business logic (prices, discounts, eligibility)
       validated server-side? Are client-only checks trusted?
    2. **Auth token storage**: Are JWTs in localStorage? Missing httpOnly/Secure/SameSite?
       OAuth flow correct for the platform?
    3. **API security**: Unauthenticated endpoints? Missing rate limiting? Permissive CORS?
       Verbose error responses? GraphQL introspection exposed?
    4. **XSS/CSP**: Weak or missing CSP? dangerouslySetInnerHTML with user data?
       unsafe-inline/unsafe-eval?
    5. **Secrets exposure**: API keys in frontend bundles? REACT_APP_/VITE_/NEXT_PUBLIC_ secrets?
    6. **Architecture**: Business logic in client code? Missing API versioning? Missing pagination?
       Direct DB connections from client?
    7. **Performance**: Bundle size over budget? Missing code splitting? Unoptimized images?
       N+1 queries? Missing connection pooling?
    8. **Platform-specific**: Electron (nodeIntegration, contextIsolation, sandbox)?
       Tauri (overly permissive commands)? Mobile (cert pinning, memory leaks)?

    For each finding: severity (MUST/DO/DON'T), file + line, confidence (0-100),
    real-world incident reference if applicable, concrete fix.
```

### Agent E: Git Blame & History Analysis

Run in parallel with Agents A-D. Provides historical context that other agents lack.

```
Agent tool call:
  - description: "Git blame and history analysis for senior-review command"
  - subagent_type: "general-purpose"
  - run_in_background: true
  - prompt: |
    Analyze the git history and blame data for the following changed files to find
    history-based issues that pure code analysis would miss.

    ## Changed Files
    [list of changed code files]

    ## Diff
    [paste the git diff output]

    ## PR Context
    [PR title and description, or branch name and recent commit messages]

    ## Instructions

    For each changed file, run:

    ```bash
    # Recent history (last 10 commits on this file)
    git log -n 10 --oneline --format="%h %ad %s" --date=short <file>

    # Blame on changed line ranges
    git blame -L <start>,<end> <file>

    # Churn frequency (commits in last 30 days)
    git log --since="30 days ago" --oneline <file> | wc -l
    ```

    Look for these patterns:
    1. **High churn** -- file changed 3+ times in the last month. Flag as risk factor
       with recent commit subjects for context.
    2. **Revert-reintroduce** -- the diff reintroduces code or patterns that were
       previously removed or reverted. Cross-reference with `git log` subjects.
    3. **Contradicting recent fixes** -- the change modifies lines that were part of
       a recent bugfix. The new change might undo the fix.
    4. **Single-author hotspot** -- all recent changes by one author, now modified
       by someone else. Flag for knowledge transfer risk.
    5. **Stale context** -- blame shows surrounding code unchanged for 1+ year while
       the diff assumes behavior that may have drifted.

    For each finding: severity (High/Medium/Low), file + line, confidence (0-100),
    description with specific commit references (hashes and subjects).

    If no history-based issues found, say so explicitly.
```

### Agent F: Testing Review (conditional)

**Only run this agent if the diff touches test files** (`test_*`, `*_test.*`, `*.spec.*`, `*.test.*`, `conftest.py`, `fixtures/`, `__tests__/`).

**Prefer `testing:test-suite-auditor` when the `testing` plugin is installed.** The `testing` plugin is an `optionalDependency` of `senior-review`: when it is not installed the spawn fails with "Agent type not found", so use the generic fallback block further below instead and note the reduced depth in the report, following the same degrade-not-fail rule as Agents D, I, and J.

Preferred variant (testing plugin installed):

```
Agent tool call:
  - description: "Testing review for senior-review command"
  - subagent_type: "testing:test-suite-auditor"
  - run_in_background: true
  - prompt: |
    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed test files + their corresponding source files]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Run your detection pipeline scoped to the modules owned by the changed
    test files (D2 to D8 on those modules; D1/D9 statistics suite-wide as
    context only). Do NOT run the full suite inside this review (no-run
    semantics): reuse CI history or existing report artifacts, and mark
    anything unmeasured as such.

    For each finding: severity (Critical/High/Medium/Low), file + line,
    confidence (0-100), description, suggested fix path.

    If the changed tests look solid, say so explicitly.
```

Fallback variant (testing plugin not installed):

```
Agent tool call:
  - description: "Testing review for senior-review command"
  - subagent_type: "general-purpose"
  - run_in_background: true
  - prompt: |
    Review the test code changes for quality, coverage gaps, and reliability.

    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed test files + their corresponding source files]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Analyze the CHANGED test code for:
    1. **Coverage gaps** -- are there untested branches, edge cases, or error paths
       in the corresponding source code?
    2. **Weak assertions** -- tests that pass but don't actually verify behavior
       (e.g., only checking status code, not response body)
    3. **Brittle tests** -- tests coupled to implementation details (mocking internals,
       hardcoded values, order-dependent assertions)
    4. **Missing edge cases** -- boundary values, empty inputs, null/None handling,
       concurrent access
    5. **Test isolation** -- shared mutable state between tests, missing setup/teardown,
       tests that depend on execution order
    6. **Fixture quality** -- overly complex fixtures, fixtures that hide important setup,
       missing factory patterns

    For each finding: severity (Critical/High/Medium/Low), file + line, confidence (0-100),
    description, suggested fix.

    If test changes look solid, say so explicitly.
```

### Agent G: API Contract Review (conditional)

**Only run this agent if the diff touches API-related files** (route definitions, serializers, type signatures, API versioning, OpenAPI/Swagger specs, GraphQL schemas).

```
Agent tool call:
  - description: "API contract review for senior-review command"
  - subagent_type: "general-purpose"
  - run_in_background: true
  - prompt: |
    Review the API contract changes for backwards compatibility and correctness.

    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed API-related files]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Analyze the CHANGED API code for:
    1. **Breaking changes** -- removed fields, renamed endpoints, changed response
       shapes, tightened input validation that rejects previously valid requests
    2. **Versioning** -- is the change backwards compatible? If not, is there a
       version bump or migration path?
    3. **Input validation** -- new endpoints missing validation, overly permissive
       schemas, type coercion risks
    4. **Response consistency** -- error response format matches existing patterns,
       pagination follows conventions, status codes are correct
    5. **Documentation sync** -- if OpenAPI/Swagger specs exist, do they match the
       implementation changes?

    For each finding: severity (Critical/High/Medium/Low), file + line, confidence (0-100),
    description, suggested fix.
```

### Agent H: Data Migrations Review (conditional)

**Only run this agent if the diff touches migration files** (database migrations, schema changes, backfill scripts, Alembic/Django/Rails/Prisma migration files).

```
Agent tool call:
  - description: "Data migrations review for senior-review command"
  - subagent_type: "general-purpose"
  - run_in_background: true
  - prompt: |
    Review the database migration changes for safety and correctness.

    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed migration files]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Analyze the migration for:
    1. **Reversibility** -- is the migration reversible? Is there a down/rollback
       function? Would rollback lose data?
    2. **Lock risk** -- will the migration lock tables during execution? For large
       tables: does it use batched operations or online DDL?
    3. **Data integrity** -- does the migration preserve existing data? Are NOT NULL
       constraints added with proper defaults? Are foreign keys safe?
    4. **Ordering** -- does this migration depend on another migration running first?
       Is the dependency declared?
    5. **Backfill safety** -- if backfilling data: is it batched? Is there a progress
       indicator? What happens if it fails midway?
    6. **Zero-downtime compatibility** -- can old code run against the new schema
       and vice versa? (column additions are safe, renames/removals are not)

    For each finding: severity (Critical/High/Medium/Low), file + line, confidence (0-100),
    description, suggested fix.
```

### Agent I: React Performance Review (conditional)

**Only run this agent if the diff touches `.tsx` or `.jsx` files AND the project has React as a dependency** (check `package.json` for `react` in dependencies/devDependencies).

**Skip if the `react-development` plugin is not installed.** It is an `optionalDependency`, so the spawn fails with "Agent type not found" when it is absent. Report the dimension as skipped for that reason instead, so the gap is visible in the report rather than silent.

```
Agent tool call:
  - description: "React performance review for senior-review command"
  - subagent_type: "react-development:react-performance-optimizer"
  - run_in_background: true
  - prompt: |
    Review the following React code changes for performance issues,
    anti-patterns, and optimization opportunities.

    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed .tsx/.jsx files]

    ## Full File Contents
    [paste full contents of each changed React file]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Analyze the CHANGED React code for:
    1. **React Compiler compatibility** -- patterns that break automatic memoization
       (external mutables, dynamic property access, non-idiomatic hooks)
    2. **Server Components** -- client-only APIs in server components, missing
       'use client' directives, unnecessary client boundaries
    3. **Re-render optimization** -- missing keys, unstable references in props,
       inline object/function creation in render, expensive computations without
       useMemo/useCallback where warranted
    4. **State management** -- derived state that should be computed, unnecessary
       state, state that belongs higher/lower in the tree
    5. **Bundle impact** -- large imports that could be lazy-loaded, barrel file
       re-exports pulling in unused code
    6. **External store subscriptions** -- useSyncExternalStore patterns,
       tearing risks with concurrent features

    For each finding: severity (Critical/High/Medium/Low), file + line, confidence (0-100),
    description, concrete fix with code example.
```

### Agent J: Abstraction & Reuse Review (conditional)

**Run this agent whenever the diff adds code**, meaning at least one added function, method, class, module, constant table, or block longer than roughly five lines. Skip it for diffs that are purely deletions, renames, formatting, or config edits.

This is the only agent that answers "was this already available?". Every other agent reads the diff and judges it on its own terms; this one takes the diff as an anchor and goes looking through the rest of the codebase for prior art.

**Skip if the `abstraction-architect` plugin is not installed.** There is no fallback: the check depends on that agent's pattern catalogs and decision frame, and a freelance grep for similar names produces false positives that cost more than the finding is worth.

```
Agent tool call:
  - description: "Abstraction and reuse review for senior-review command"
  - subagent_type: "abstraction-architect:abstraction-architect"
  - run_in_background: true
  - prompt: |
    [Include shared instructions: Intent + Diff Scope]

    mode: diff
    codebase_path: [repo root]
    deep_dive_path: [.deep-dive/ if Step 2 produced one, otherwise "none"]
    changed_files: [list of changed files]
    report_path: [scratch path for this review]
    severity_floor: medium

    ## Diff
    [paste the git diff output]

    ## Instructions
    Follow the `PROCESS (mode = diff)` section of your agent definition.

    Your search space is the WHOLE codebase, not the diff. The prior art you are
    hunting for is by definition in files that did not change, so never limit
    Grep to the changed files.

    Report classes R1 (exact prior art), R2 (near prior art), R3 (Rule of Three
    reached on this diff), and R5 (wrong abstraction introduced). Note R4 second
    occurrences in their own section without flagging them.

    Do NOT re-flag single-file smells that `senior-review:code-auditor` already
    owns: leaky abstractions, premature interfaces with one implementation, and
    god objects visible inside one file. Your findings must cite at least one
    site outside the diff.

    For each finding: severity (Critical/High/Medium/Low), file + line for BOTH
    the new code and the prior art, confidence (0-100), the behavioral difference
    if any, and the suggested direction in one sentence.
```

### Agent K: TypeScript Type-Safety Review (conditional)

**Only run this agent if the diff touches `.ts` or `.tsx` files AND `tsconfig.json` exists at the project root.** On React projects both Agent I and Agent K run: the charters are orthogonal (performance vs type safety) and consolidation deduplicates any collision.

**Skip if the `typescript-development` plugin is not installed.** It is an `optionalDependency`, so the spawn fails with "Agent type not found" when it is absent. Report the dimension as skipped for that reason instead, so the gap is visible in the report rather than silent.

```
Agent tool call:
  - description: "TypeScript type-safety review for senior-review command"
  - subagent_type: "typescript-development:type-safety-auditor"
  - run_in_background: true
  - prompt: |
    Review the following TypeScript changes for type-system erosion.

    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed .ts/.tsx files]

    ## tsconfig
    [paste tsconfig.json and any extended configs]

    ## Full File Contents
    [paste full contents of each changed TypeScript file]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Analyze the CHANGED TypeScript code for:
    1. **Any erosion**: explicit any, untyped JSON.parse and response.json() results, any generic defaults
    2. **Unsound casts**: shape-changing as casts without runtime checks, as unknown as bypasses
    3. **Boundary validation**: HTTP payloads, queue messages, storage reads, and env access reaching typed code without a schema parse or guard
    4. **Assertion abuse**: unjustified non-null assertions, @ts-ignore instead of @ts-expect-error with reason
    5. **Configuration drift**: strict, noUncheckedIndexedAccess, exactOptionalPropertyTypes missing or weakened by this diff
    6. **Exhaustiveness**: discriminated-union switches without never defaults, lookup tables without satisfies
    7. **Generics soundness**: unconstrained exported type parameters, type predicates that do not verify the shape they claim

    Cite rule ids from the type-safety-rules skill in every finding.
    For each finding: severity (Critical/High/Medium/Low), file + line, confidence (0-100),
    description, concrete fix with a code example.
```

### Agent L: Temporal Resilience Review (conditional)

**Only run this agent if the diff touches long-running or scheduled execution machinery**: timers (`setInterval`/`setTimeout` chains, cron), polling loops, retry/reconnect/backoff logic, queue workers, background daemons, updaters, watchdogs, or heartbeats. Detection: grep the diff for `setInterval|setTimeout|cron|schedule|retry|reconnect|backoff|watchdog|heartbeat|keepalive|poll|daemon|updater`. This agent lives in `senior-review` itself, so there is no plugin-availability check.

This dimension exists because the synchronous lenses (A through K) each see the code in an instant; none of them owns the question "what does the user see after this has been failing for a day". Resilience findings otherwise fall on the seam between architecture and performance, and each reviewer sees only half.

```
Agent tool call:
  - description: "Temporal resilience review for senior-review command"
  - subagent_type: "senior-review:temporal-resilience-auditor"
  - run_in_background: true
  - prompt: |
    Review the following changes for failure-over-time behavior.

    [Include shared instructions: Intent + Diff Scope]

    ## Changed Files
    [list of changed files matching the temporal signals]

    ## Full File Contents
    [paste full contents of each changed file containing temporal machinery]

    ## Diff
    [paste the git diff output]

    ## Instructions
    Follow your agent definition's analysis phases: inventory the temporal
    machinery, run the three-horizon failure analysis (1st failure, Nth failure,
    never-ending failure), hunt silent-death paths (unbounded awaits, guard
    flags without finally, timers that stop re-arming, catch-and-continue
    erosion, missing escalation), trace the user-visible consequence of every
    failure path, and check clock/suspend/DST hazards.

    Label every quantitative claim `measured` or `derived` per your EVIDENCE
    CLASSES section. If you build a measurement harness, keep it outside the
    work tree and delete it; report the numbers and method in the finding.

    For each finding: severity (Critical/High/Medium/Low), file + line,
    confidence (0-100), failure chain, quantified damage with evidence class,
    user-visible consequence, concrete fix.
```

---

## Step 4: Consolidate Findings & Extract Score

After all agents complete, run the merge pipeline:

### 4a. Confidence Gating

Apply a three-tier confidence filter to all findings:

| Confidence | Action |
|------------|--------|
| **< 0.50 (< 50%)** | **Suppress** -- finding is speculative, discard it. Record suppressed count. |
| **0.50 - 0.69** | **Flag** -- include in report but mark as low-confidence |
| **>= 0.70** | **Report** -- full confidence, include normally |

### 4b. Deduplication

When multiple agents flag the same issue, merge them:

1. Compute fingerprint: `normalize(file) + line_bucket(line, +-3) + normalize(title)`
2. When fingerprints match:
   - Keep the **highest severity**
   - Keep the **highest confidence** with strongest evidence
   - **Union** the evidence from all agents
   - Note which agents flagged it (shows cross-agent agreement)
3. Record the dedup count

### 4c. Separate Pre-existing

Pull out findings with `[PRE-EXISTING]` prefix into a separate list. These are reported in their own section and do NOT count toward the verdict.

### 4d. Sort & Score

- Sort by severity (Critical first) -> confidence (descending) -> file path -> line number
- Extract the Code Quality Score from code-auditor (Agent A) directly

## Step 4b: Adversarial Verification Panel

Skip this step if `--fast` was passed. Otherwise verify findings with the 3-lens panel defined in the `senior-review:review-quality-gates` skill, section `## Adversarial Verification Panel`. This replaces the former single-validator step: three independent lenses (reachability/correctness, false-positive causes, severity) catch more failure modes than one judge, and the scope widens from Critical/High only to every finding above the confidence floor.

If the skill is unavailable, fall back to the legacy behavior: one `general-purpose` validator per Critical/High finding returning VALID/FALSE_POSITIVE (opus for bug/logic/architecture findings, sonnet for style/CLAUDE.md findings).

### Selection

- **Default:** every finding with confidence `>= 50%` that survived Step 4b deduplication, regardless of severity.
- **Cost guard** (more than 25 surviving findings AND `--rigorous` not set): narrow to all Critical/High plus any Medium/Low in the 50-75% confidence band or with conflicting reviewer severity. The rest pass through tagged `unverified (cost-guard)`. Note the narrowing in the report.
- **`--rigorous`:** verify everything above the floor, ignoring the cap.

The cost-guard threshold is a finding-count proxy (no token budget exists in this substrate).

### Panel

For each selected finding, spawn the three lenses in parallel using the lens prompts from the skill (`general-purpose`; `opus` for lenses 1-2, `sonnet` for lens 3; `run_in_background: true`), substituting the finding, the diff, and the full file content.

### Survival rule

Apply the skill's rule: survive on `>= 2` of lenses 1-2 voting REAL; discard (`filtered`, counted) on `>= 2` FALSE_POSITIVE; tie or fewer-than-2-verdicts means survive and mark `contested`. Final severity is the lens-3 vote when confirmed real, else the original.

**After the panel completes:**
- Drop `filtered` findings; apply recalibrated severities; tag `contested` and `unverified (cost-guard)` findings.
- Add to the report: `Verification: X of Y (3-lens panel), Z false positives, W contested`.

Medium and Low findings are no longer skipped by default: they enter the panel like any other finding above the floor (subject to the cost guard).

## Step 4c: Completeness Critic

Skip this step if `--fast` was passed. Otherwise run the critic defined in the `senior-review:review-quality-gates` skill, section `## Completeness Critic` (if the skill is unavailable, skip this step).

1. Spawn one `general-purpose` critic with the skill's critic prompt. Pass the verified findings, the changed-file scope, the agents that ran, and the deep-dive context paths if `.deep-dive/` exists (else "none").
2. If the critic names a single high-risk uncovered area under `## Recommended follow-up` AND the cost guard did not fire: spawn ONE targeted reviewer (the most specialized agent for that area) scoped to the files named, then route its findings back through Step 4 (dedup) and Step 4b (panel). At most one round.
3. Otherwise degrade to report-only.
4. Carry the critic's `## Coverage Gaps` list into the Step 5 report.

## Step 5: Final Review Output

After validation completes, synthesize everything into the final structured review:

```
## Code Review -- [PR title or branch name]

### Review Scope
- **Scope:** [diff source -- e.g., origin/main..HEAD, uncommitted changes, PR #42]
- **Intent:** [2-3 line intent summary from Step 1b]
- **Reviewers:** code-auditor, security-auditor, dead-code, [+ conditional agents with justification]
- Files reviewed: [N]
- Lines changed: +X / -Y
- CLAUDE.md compliance: [checked / not found]
- Verification: X of Y findings verified (3-lens panel), Z false positives, W contested{cost_guard_note}

### Overall Score: X/10 (confidence: X%)

### Critical & High Findings
| # | Severity | File:Line | Finding | Confidence | Fix |
|---|----------|-----------|---------|------------|-----|
| 1 | Critical | ...       | ...     | 95%        | ... |

### Medium & Low Findings
| # | Severity | File:Line | Finding | Confidence | Fix |
|---|----------|-----------|---------|------------|-----|

### Dead Code & Unused Parameters
| # | Source | Severity | File:Line | Finding | Confidence | Action |
|---|--------|----------|-----------|---------|------------|--------|

### Failure Flow & Resilience
| # | Severity | File:Line | Scenario | Confidence | Fix |
|---|----------|-----------|----------|------------|-----|

### UI Race Conditions (if applicable)
| # | Severity | File:Line | Timeline | Confidence | Fix |
|---|----------|-----------|----------|------------|-----|

### Platform Engineering (if applicable)
| # | Severity | File:Line | Rule | Confidence | Fix |
|---|----------|-----------|------|------------|-----|

### Git History & Churn (if applicable)
| # | Severity | File:Line | Pattern | Commits Referenced | Confidence |
|---|----------|-----------|---------|-------------------|------------|

### Testing Issues (if applicable)
| # | Severity | File:Line | Finding | Confidence | Fix |
|---|----------|-----------|---------|------------|-----|

### API Contract Issues (if applicable)
| # | Severity | File:Line | Finding | Confidence | Fix |
|---|----------|-----------|---------|------------|-----|

### Data Migration Issues (if applicable)
| # | Severity | File:Line | Finding | Confidence | Fix |
|---|----------|-----------|---------|------------|-----|

### React Performance (if applicable)
| # | Severity | File:Line | Finding | Confidence | Fix |
|---|----------|-----------|---------|------------|-----|

### Abstraction & Reuse (if applicable)
| # | Class | Severity | New Code | Prior Art | Difference | Direction |
|---|-------|----------|----------|-----------|------------|-----------|

Second occurrences (R4), listed without flagging: [one line each, or "none"]

### Coverage
- Suppressed: [N] findings below 0.50 confidence
- Deduplicated: [N] cross-agent duplicates merged
- Residual risks: [risks noticed but not confirmed as findings]
- Testing gaps: [missing test coverage identified]

### Coverage Gaps
[paste the ## Coverage Gaps list from the completeness critic, or "None identified"]

### Pattern Consistency
- [pattern deviations found, or "Changes follow established patterns"]

### CLAUDE.md Compliance
- [list any violations, or "All changes comply with project conventions"]

### Pre-existing Issues (does not count toward verdict)
| # | File:Line | Issue | Reviewer |
|---|-----------|-------|----------|
[issues in unchanged code unrelated to the diff, or "None"]

---

> **Verdict:** [Ready to merge / Ready with fixes / Not ready]
>
> **Reasoning:** [1-2 sentences explaining why]
>
> **Fix order:** [severity-ordered list of what to fix first, if applicable]
```

Where `{cost_guard_note}` is `, narrowed to stakes+band (N unverified)` when the cost guard fired, else empty.

If `--strict` and there are Critical findings:

```
STRICT MODE: Critical issues found. Not ready to merge.
```

## Step 5b: CLAUDE.md Alignment Check

After producing the review output, check if findings suggest the project's `CLAUDE.md` is stale:

1. Read `CLAUDE.md` (if it exists -- it was already read in Step 2)
2. Cross-reference review findings with documented conventions, structure, and workflows
3. If any documented information is outdated or missing, add a `### CLAUDE.md Staleness` section to the review output noting what needs updating

---

## Step 6: Auto-Comment on PR (if --auto-comment)

If `--auto-comment` flag is set and reviewing a PR:

Post only **CRITICAL and HIGH severity** findings as inline PR comments. Do NOT auto-comment MEDIUM or LOW findings -- include those only in the summary report. This prevents comment spam and focuses reviewer attention on what matters.

Write each comment body to a temp file first, then use `-F` to avoid shell injection from LLM-generated content.

### Committable Suggestions

For each inline comment, decide whether to include a committable suggestion:

- **Include suggestion** when the fix is small and self-contained (< 6 lines changed, single location, committing the suggestion fully resolves the issue)
- **No suggestion** when the fix is large (6+ lines), structural, spans multiple locations, or committing the suggestion alone would not fully fix the problem
- **Never** post a committable suggestion unless committing it fixes the issue entirely -- partial suggestions that require follow-up steps are worse than no suggestion

### Inline comment format

```bash
mkdir -p .code-review-tmp

# Without committable suggestion (large or multi-location fix)
cat > .code-review-tmp/temp_inline_comment.md << 'COMMENT_EOF'
**[Severity]** -- [finding summary]

[concrete fix recommendation describing what to change]
COMMENT_EOF

# With committable suggestion (small, self-contained fix)
cat > .code-review-tmp/temp_inline_comment.md << 'COMMENT_EOF'
**[Severity]** -- [finding summary]

```suggestion
[corrected code that fully fixes the issue when committed]
```
COMMENT_EOF

# Post as inline PR comment using -F (file input)
gh api repos/{owner}/{repo}/pulls/{number}/comments \
  -F body=@.code-review-tmp/temp_inline_comment.md \
  -f path="[file]" \
  -f line=[line] \
  -f commit_id="$(gh pr view {number} --json headRefOid --jq '.headRefOid')"
```

Post the overall summary as a regular PR comment (also via temp file):

```bash
mkdir -p .code-review-tmp

cat > .code-review-tmp/temp_summary_comment.md << 'SUMMARY_EOF'
## Automated Code Review

**Overall Score: X/10**

[summary of critical/high findings]

[top 3 recommended actions]

---
*Reviewed by: code-auditor, security-auditor, dead-code-and-lint-detector, ui-race-auditor, git-history-analyzer | Findings verified by 3-lens panel*
SUMMARY_EOF

gh pr comment {number} -F .code-review-tmp/temp_summary_comment.md
```

---

## Step 7: Fix Loop (if --fix or verdict is "Ready with fixes")

After presenting the review (Step 5/6), offer an interactive fix cycle. Skip this step if the verdict is "Ready to merge" with no findings, or if the user didn't request fixes.

The loop has two kinds of work: targeted fixes for review findings (7b) and bulk removal for codebase-hygiene findings (7c). The second is the only place in the marketplace that deletes application code at scale (bulk removal of test files belongs to the `testing` plugin's gated `/testing:test-consolidate` workflow), so it carries its own pre-flight, gates, and per-phase commits. A review with no hygiene findings skips 7c entirely.

### 7a. Severity Acceptance

Present a single prompt listing all severity levels with findings. Use `AskUserQuestion` with `multiSelect: true`:

When Critical or High findings exist:
- [x] **Critical + High (Recommended)** -- N issues
- [ ] **Medium** -- N issues
- [ ] **Low** -- N issues

When only Medium/Low findings exist:
- [ ] **Medium** -- N issues
- [ ] **Low** -- N issues

Only include severity levels that have findings.

### 7b. Apply Fixes

For the selected severities, spawn one or more fix subagents:

```
Agent tool call:
  - description: "Fix [N] review findings"
  - subagent_type: "general-purpose"
  - prompt: |
    Fix the following code review findings. For each finding, apply the
    minimal correct fix. Run tests after fixing to verify no regressions.

    ## Findings to Fix
    [filtered findings at selected severities with file:line and suggested fix]

    ## Rules
    - Fix ONLY the listed findings, do not refactor surrounding code
    - Run existing tests after each fix
    - If a fix would require significant refactoring, note it and skip
    - Commit each fix or batch of related fixes
```

Wait for all fixes to complete before proceeding.

### 7c. Cleanup Phases

Run this sub-step only when the accepted findings include codebase-hygiene items (dead code, orphan assets, generated artifacts tracked in VCS, unused or phantom deps, stale docs). Skip it entirely otherwise. This is the only place in the marketplace that performs bulk removal of application code (test-file bulk removal is owned by the `testing` plugin's gated `/testing:test-consolidate` workflow); detection lives in `senior-review:cleanup-auditor` and in Agent B2 above, and neither of them deletes anything.

#### Critical rules

These are non-negotiable. Removal at this scale is safe only because of them.

1. **Git pre-flight.** `git status` must be clean before the first phase. Warn and halt if the working tree has uncommitted changes. Fixes from 7b must already be committed.
2. **Phase isolation.** Each phase gets its own commit, never mixing categories, so every step is independently revertible.
3. **Gate after every phase.** The project build must pass and tests must not regress against the baseline recorded before the first phase. On either failure, `git reset --hard HEAD~1` and halt.
4. **Grep-before-delete.** For every asset, export, or dependency candidate, run a final confirmation Grep and proceed only on zero results. Skip any item with matches and log it separately.
5. **Never remove what is used through side effects.** Dynamic imports, decorators, framework conventions (Next.js `pages/` and `app/`, Django views, pytest fixtures), and module augmentation in `*.d.ts` with `declare module`.
6. **Python functions and classes require explicit approval.** vulture's false-positive rate is high; present them separately and wait for user confirmation.

#### Baseline

Before the first phase, record the starting commit (`git rev-parse HEAD`), run the build, and run the test suite to capture pass and fail counts. Resolve `BUILD_CMD` and `TEST_CMD` from the project (`package.json` scripts, `pyproject.toml`, or the project equivalent), preferring unit tests over e2e. If the baseline build or tests already fail, halt: the branch must be stable before subtraction.

#### Phase order

Lowest risk first, stopping at the first gate failure. Run only the phases the accepted findings actually require.

1. `garbage` -- filesystem cruft (`nul`, `.DS_Store`, shell-redirection artifacts). Safest phase, no build or dependency impact expected.
2. `brand` -- rebrand residue. Requires the user to confirm the old brand name first.
3. `assets` -- orphan static files. Watch for dynamic references built from template literals, so Grep partial basenames too. For eager `import.meta.glob` bloat, switch to `{ eager: false }` with lazy resolution rather than removing the glob, unless every file in it is provably unused; removing the glob needs user sign-off.
4. `gitignore` -- append missing patterns, then `git rm --cached` for currently-tracked files the new patterns now match. Regenerate `.gitignore` only if it was empty or clearly minimal; otherwise append.
5. `deps` -- unused and phantom dependencies. Move phantom deps to the correct workspace's manifest instead of deleting them unless confirmed unused everywhere. Re-install after editing and commit the manifest together with the lockfile. Never touch implicitly-used devDependencies (`prettier`, `eslint`, `typescript`, `@types/*` matching runtime deps) without grepping config files first.
6. `exports` -- dead exports, types, files, and unused Python symbols, in ascending risk order: ruff `F401` and `F841` auto-fix, then Knip unused exports and types verified by Grep across all workspaces, then Knip unused files verified against dynamic require and framework-convention paths, then vulture functions and classes under rule 6.
7. `docs` -- stale documentation and historical artifacts. Last on purpose, so it also catches doc references made stale by the `exports` phase. Detection-only unless the user explicitly opts into removal.

#### Per-phase template

For every phase `P`:

- **P.1 Confirm zero references.** Grep each candidate across source and docs, excluding the file being removed. Skip anything with a match.
- **P.2 Apply removals in batches** of 5 to 20 items. Delete files or edit export lines for code, `git rm` for assets, `git rm --cached` for generated artifacts, manifest edit plus re-install for deps, append for `.gitignore`.
- **P.3 Gate.** Run `BUILD_CMD` then `TEST_CMD`. On failure, `git reset --hard HEAD~1`, report which phase failed, and halt.
- **P.4 Commit.** One commit per phase: `chore(cleanup): <phase> -- <count> items removed`, with a short summary of what went in the body.
- **P.5 Proceed** to the next phase, or halt if the gate failed.

#### The docs phase

Highest false-positive rate of the seven, so removal is opt-in and gated per item.

- Without an explicit opt-in, output the categorized report and stop.
- Plans, ADRs, and archive folders need per-item confirmation. A stale plan is indistinguishable from an active one to a tool. Show path, last-modified date, checklist completion percentage, and the first few lines of the body.
- Scratch directories: untracked and already in `.gitignore` means safe local cleanup with no commit. Tracked means `git rm -r` plus a `.gitignore` entry, committed normally.
- Stale doc references are edits, not deletions. Rewrite the paragraph or strike the bullet; never delete a whole document over one stale link. If a document ends up effectively empty, propose its deletion as a separate confirmed item.
- Orphan doc-assets follow the same Grep-before-delete rule, searching only `*.md`, `*.mdx`, `*.rst`, `*.adoc`. Watch for inline base64 images that reference no filename.
- ADRs are historical record. The default action for `Status: Superseded` is to move them under a `superseded/` subfolder, not to delete them.

#### Cleanup report

After the last phase, or at the first gate failure, present one row per phase with status, items removed, and the commit sha, plus the before-and-after test counts and the reverted phase if any. Then run the alignment check: Grep the removed symbols, paths, and dependency names against `CLAUDE.md` and propose updates for any hit, since a cleanup that leaves the project instructions describing deleted code has only moved the problem.

This step is pure subtraction. It does not refactor architecture, does not touch test files unless they reference removed symbols, and does not run a bundle analyzer.

### 7d. Re-review Offer

After fixes land, present:
- **Run another review round (Recommended)** -- verify fixes and check for new issues
- **Proceed without re-review**

If another round: run the full Step 1-7 flow again (fresh agents, fresh scope).

### 7e. Post-fix Options

After the fix-review cycle completes (clean verdict or user chose to stop):

**On a feature branch:**
- **Create a PR (Recommended)** -- push and open via `gh pr create`
- **Continue without PR**

**On main/master:**
- **Continue**

$ARGUMENTS
